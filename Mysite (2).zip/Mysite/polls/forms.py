from django import forms

CATEGORY_CHOICES = [
    ('Food', 'Food'),
    ('Snacks', 'Snacks'),
    ('Drinks', 'Drinks'),
    ('Hardware', 'Hardware'),

]

class ProductForm(forms.Form):
    product_name = forms.CharField(max_length=100)
    category = forms.ChoiceField(choices=CATEGORY_CHOICES)
    description = forms.CharField(widget=forms.Textarea)
    rating = forms.DecimalField(max_digits=3, decimal_places=2)
